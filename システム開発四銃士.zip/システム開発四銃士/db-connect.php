<?php
const SERVER ='mysql309.phy.lolipop.lan';
const DBNAME ='LAA1516823-sports';
const USER ='LAA1516823';
const PASS ='pass0905';

$connect = 'mysql:host='. SERVER . ';dbname='. DBNAME . ';charset=utf8';

?>